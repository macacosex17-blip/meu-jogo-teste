import time
import os

os.system('cls' if os.name == 'nt' else 'clear')
print('====================================')
print('   BEM-VINDO AO JOGO TESTE v1.0!    ')
print('====================================')
print('Parabéns! O seu launcher funcionou e o jogo está rodando.')
print('\n')
input('Pressione ENTER para sair...')versãoa tualziada atualemnte
