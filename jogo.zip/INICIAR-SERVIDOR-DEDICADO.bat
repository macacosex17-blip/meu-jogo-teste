@echo off
cd /d "%~dp0"
title Servidor Dedicado - Duelo de Nacoes
:loop
echo =========================================
echo Iniciando servidor dedicado...
if exist "multiplayer-tools\vendor\node.exe" (
  "multiplayer-tools\vendor\node.exe" "multiplayer-tools\servidor-dedicado.cjs"
) else (
  node "multiplayer-tools\servidor-dedicado.cjs"
)
echo.
echo [!] O servidor caiu ou foi fechado! Reiniciando automaticamente em 5 segundos...
timeout /t 5 >nul
goto loop
